<!-- This page saves the data entered by user in to the database after required validations -->
<?php

$message='';
if (isset($_POST['register']))
{
    require 'dbconnect.php';//Establishing connection with database
    $employeeid=$serviceid='';
    //Retreiving values sent by http post method
    $employeeid=$_REQUEST['employee'];
    $serviceid=$_REQUEST['MassageType'];
    // echo $_REQUEST['service'].'not';
        //Checking if the email already exists in the database
        $sql="SELECT * FROM TherapistDetails WHERE EmployeeId=$employeeid AND ServiceId=$serviceid";
        $result=mysqli_query($mysqli,$sql);
        if($row = $result->fetch_row())//If email already registered
        {
           $message="Entry already exists in database.";
        }
          else//if email is not already used
          {
            
            $sqlsp = "CALL spAssignService('$employeeid', '$serviceid')";
           // echo $employeeid;
           // echo $serviceid;
            if (!$mysqli->query($sqlsp)){//If SP execution failed.
            $message='Failed to Assign Service.';
            echo($mysqli->error);
             } 
            else {
                //Saving values to session variables to use later.
               // echo $employeeid;
                // echo '</br>';
                // echo $serviceid;
                $message="Service Assigned";
              // header("Location: AssignServices.php");//redirecting to Assign services page                       
                }
          }     
         
}
?>
