 <!--Header for the application -->
 <!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="stylesheet.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
    </head>
    <body> 
            <nav id="navbar" style="height:30px;text-align:right;">
            
                <ul >
                    
                     <a href="#" style="text-align:right;">Home</a>|
                     <a href="#" style="text-align:right;">About</a>|
                     <a href="#" style="text-align:right;">Contact Us</a>
                </ul>
            </nav>
    </body>
</html>