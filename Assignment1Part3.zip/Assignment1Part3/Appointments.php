<!-- Page to welcome user on successful registration -->
<html>
<head>
        <title>Appointments</title>
        <link rel="stylesheet" type="text/css" href="stylesheet.css">
        <!-- <link rel="stylesheet" href="bootstrap.css"> 
        <link rel="stylesheet" href="bootstrap.min.css">  -->
        <?php require("usertab.php"); ?>
    
     
</head>
<body>   

<!-- <?php
// include('RegisterDB.php');
// if (isset($_SESSION['firstname']))
// {
//     $firstname=$_SESSION['firstname'];// Getting the firstname from the session variable.
                         
// }
?> -->
<div class="flex-container">
<div>
Massage 1
</div>
<div>
Massage 2
</div>
</div>          
</body>
<?php require("footer.php"); ?>
</html>