<?php 
 require 'dbconnect.php';
 require("admincheck.php"); 
 $fname=$_SESSION['firstname'];
     $lname=$_SESSION['lastname'];
     $email=$_SESSION['username'];
     $empid=$_SESSION['empid'];
     $currentDateTime = date('Y-m-d');
 $query = "SELECT * FROM Bookings WHERE EmployeeId='$empid'AND BookingStatus<>'Cancelled'";
 $result = mysqli_query($mysqli, $query);
?>
<!DOCTYPE html>
<html>
<head>
<style>
.flex-container {
  display: flex;
  flex-direction: row;
  background-color: DodgerBlue;
}

.flex-container > div {
  background-color: #f1f1f1;
  width: 100px;
  margin: 10px;
  text-align: center;
  line-height: 75px;
  font-size: 30px;
}
</style>
</head>
<body>
<h1>Your upcoming bookings</h1>

<p>The "flex-direction: column;" stacks the flex items vertically (from top to bottom):</p>

<div class="flex-container">
<div>
<table class="table table-bordered">  
                                <?php  
                               while($row = mysqli_fetch_array($result))  
                               {  $id=$row["BookingId"];
                               ?>  
                               <tr>  
                                   
                                    <td><?php echo $row["MassageType"]." on ".$row['BookedDate']; ?></td>  
                                    <td><a href="Edit.php?id=<?php echo $id; ?>"     class="btn">Edit</td>
                                   <td><a href="Delete.php?id=<?php echo $id; ?>" class="btn">Cancel</td>
                                   <td><a href="View.php?id=<?php echo $id; ?>" class="btn">View</td>
                                    <!-- <td><input type="button" name="edit" value="Edit" id="<?php echo $row["BookingId"]; ?>" class="btn btn-info btn-xs edit_data" /></td>  
                                    <td><input type="button" name="edit" value="Cancel" id="<?php echo $row["BookingId"]; ?>" class="btn btn-info btn-xs delete_data" /></td>  
                                    <td><input type="button" name="view" value="View" id="<?php echo $row["BookingId"]; ?>" class="btn btn-info btn-xs view_data" /></td>   -->
                               </tr>  
                               <?php  
                               }  
                               ?>  
                          </table>  
</div>
  <div>2</div>
  <div>3</div>  
</div>

</body>
</html>
