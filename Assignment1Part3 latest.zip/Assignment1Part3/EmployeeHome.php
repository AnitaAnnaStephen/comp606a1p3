<!-- Page to welcome user on successful registration -->
<html>
<head>
        <title>Employee Home</title>
        <link rel="stylesheet" type="text/css" href="stylesheet.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <?php require("heading.php"); ?>
        <?php require("admincheck.php"); 
        $message='';?>
</head>
<body style="background-color:silver;">   
<span style="color:red;"><?php echo $message; ?></span>
<?php

if (isset($_SESSION['firstname']))
{
    $firstname=$_SESSION['firstname'];// Getting the firstname from the session variable.
    //Welcome message for the newly registered user.
     echo '<p1>Hello '.$firstname.',</p1>';
     echo  '</br>';
     echo  '<a href="ViewBookings.php">View Bookings</a>';//View Booking Details
     echo  '</br>';
     
     echo  '</br>';
                          
}
?>
<a href="Logout.php" style="font-weight:bold;background-color:Blue;">Logout</a>
</body>
<?php require("footer.php"); ?>
</html>