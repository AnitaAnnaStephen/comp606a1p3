<!-- Page to welcome user on successful registration -->
<html>
<head>
        <title>Book Appointment</title>
        <link rel="stylesheet" type="text/css" href="stylesheet.css">
        <!-- <link rel="stylesheet" href="css/bootstrap.min.css"> -->
        <?php require("usertab.php"); ?>
        <style>
        .appointment {
    background-color: darkslategray;
    width: 200px;
    padding: 25px;
    border: 25px solid floralwhite;
  }
  .flex-container {
  display: flex;
  justify-content: center;
  background-color: floralwhite;
}

.flex-container > div {
  background-color: gray;
  width: 300px;
  margin: 40px;
  text-align: center;
  line-height: 75px;
  font-size: 30px;
}
  </style>  
</head>
<body>   
<div class="flex-container">
<div>
<form action="Dateandtime.php">
  Sports Massage<br>
  Rate : <label>$45 </label>
  <br>
  Time :<label>30 minutes </label>
  <br>
  <input type="submit" value="Book Now" style="background-color:black;border-radius:10px;color:white;height: 40px;">
</form> 
</div>
<div>
<form action="Dateandtime.php">
  Sports Massage <br>
  Rate : <label>$60 </label>
  <br>
  Time :<label>60 minutes </label>
  <br>
  <input type="submit" value="Book Now" style="background-color:black;border-radius:10px;color:white;height: 40px;">
</form>
</div>
<div>
<form action="Dateandtime.php">
  Therapeutic Massage<br>
  Rate : <label>$45 </label>
  <br>
  Time :<label>30 minutes </label>
  <br>
  <input type="submit" value="Book Now" style="background-color:black;border-radius:10px;color:white;height: 40px;">
</form>
</div>
<div>
<form action="Dateandtime.php">
Therapeutic Massage<br>
  Rate : <label>$60 </label>
  <br>
  Time :<label>60 minutes </label>
  <br>
  <input type="submit" value="Book Now" style="background-color:black;border-radius:10px;color:white;height: 40px;">
</form>
</div>

</div>          
</body>
<?php require("footer.php"); ?>
</html>